<?php
// PASTE YOUR EMAIL
$caseymail = 'supportcaseyhost@gmail.com'; // GANTI EMAIL KAMU DISINI

// SCRIPT 18+ BY CASEY HOST
// TANGGAL PEMBUATAN 13 SEPTEMBER 2021
// FACEBOOK : www.facebook.com/caseyhostt
// WHATSAPP : wa.me/+14508232332
// YOUTUBEE : CaseyHost
// TELEGRAM : t.me/CaseyHost
?>
